import os
import discord
from discord.ext import commands
from discord import app_commands
import sqlite3
import time
import random

# ================= CẤU HÌNH CẢNH GIỚI & LINH CĂN =================
REALMS = [
    {"name": "Phàm Nhân", "max_exp": 100, "rate": 1.0, "hp": 100, "atk": 10, "def": 5},
    {"name": "Luyện Khí - Sơ Kỳ", "max_exp": 300, "rate": 0.90, "hp": 250, "atk": 25, "def": 12},
    {"name": "Luyện Khí - Trung Kỳ", "max_exp": 700, "rate": 0.80, "hp": 500, "atk": 50, "def": 25},
    {"name": "Luyện Khí - Hậu Kỳ", "max_exp": 1500, "rate": 0.70, "hp": 900, "atk": 90, "def": 45},
    {"name": "Luyện Khí - Đỉnh Phong", "max_exp": 3000, "rate": 0.60, "hp": 1500, "atk": 150, "def": 80},
    {"name": "Trúc Cơ - Sơ Kỳ", "max_exp": 6500, "rate": 0.45, "hp": 3500, "atk": 350, "def": 180},
    {"name": "Trúc Cơ - Trung Kỳ", "max_exp": 14000, "rate": 0.40, "hp": 6000, "atk": 600, "def": 300},
    {"name": "Trúc Cơ - Hậu Kỳ", "max_exp": 28000, "rate": 0.35, "hp": 10000, "atk": 1000, "def": 500},
    {"name": "Kết Đan - Sơ Kỳ", "max_exp": 60000, "rate": 0.25, "hp": 25000, "atk": 2500, "def": 1200},
    {"name": "Nguyên Anh - Sơ Kỳ", "max_exp": 150000, "rate": 0.15, "hp": 70000, "atk": 7500, "def": 3500},
    {"name": "Hóa Thần - Sơ Kỳ", "max_exp": 400000, "rate": 0.10, "hp": 200000, "atk": 22000, "def": 10000},
]

SPIRIT_ROOTS = [
    {"name": "Ngụy Linh Căn (Ngũ Hành Khuyết)", "speed": 0.8, "weight": 45, "desc": "Linh khí tạp loạn, con đường tu đạo gian nan gấp bội."},
    {"name": "Chân Linh Căn (Hỏa - Mộc)", "speed": 1.2, "weight": 35, "desc": "Tư chất trung đẳng, thích hợp luyện đan và tu luyện chính thống."},
    {"name": "Dị Linh Căn - Phong Hệ", "speed": 1.7, "weight": 7, "desc": "Biến dị linh căn hiếm gặp, thân pháp và tốc độ hấp thụ linh khí cực nhanh."},
    {"name": "Dị Linh Căn - Lôi Hệ", "speed": 1.9, "weight": 8, "desc": "Chưởng quản sấm sét, sát phạt quả đoán, khắc chế tà ma."},
    {"name": "Thiên Linh Căn (Cực Phẩm Thủy)", "speed": 2.5, "weight": 4, "desc": "Thiên đạo sủng nhi, trước Kết Đan cơ hồ không có bình cảnh."},
    {"name": "Hỗn Độn Tiên Thiên Linh Căn", "speed": 4.0, "weight": 1, "desc": "Vạn năm có một, dung nạp hồng mông tử khí, kinh thiên động địa!"},
]

FAIL_MESSAGES = [
    "tâm ma quấy nhiễu lúc xung quan, kinh mạch nghịch chuyển mà thổ huyết!",
    "không chịu nổi uy áp của Cửu Cửu Thiên Kiếp, đạo cơ bị tổn hại!",
    "linh khí trong đan điền bạo động, suýt chút nữa thân tử đạo tiêu!",
    "ngộ đạo chưa thông, vội vàng cưỡng ép đột phá dẫn đến tẩu hỏa nhập ma!"
]

DB_NAME = "tutien_chinh_thong.db"

# ================= QUẢN LÝ CƠ SỞ DỮ LIỆU =================
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS players (
                    user_id INTEGER PRIMARY KEY,
                    name TEXT,
                    linh_can TEXT,
                    speed REAL,
                    realm_idx INTEGER DEFAULT 0,
                    exp INTEGER DEFAULT 0,
                    linh_thach INTEGER DEFAULT 100,
                    bonus_rate REAL DEFAULT 0.0,
                    last_cultivate INTEGER,
                    last_explore INTEGER DEFAULT 0
                )""")
    conn.commit()
    conn.close()

def get_player(user_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM players WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    return row

def update_cultivation(user_id):
    player = get_player(user_id)
    if not player:
        return None, 0

    uid, name, linh_can, speed, realm_idx, exp, linh_thach, bonus_rate, last_time, last_explore = player
    now = int(time.time())
    elapsed = max(0, now - last_time)

    # Tốc độ cơ bản: 12 Linh khí / phút * Hệ số Linh Căn * Hệ số Cảnh giới
    realm_bonus = 1 + (realm_idx * 0.25)
    gained_exp = int((elapsed / 60) * 12 * speed * realm_bonus)
    new_exp = exp + gained_exp

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE players SET exp = ?, last_cultivate = ? WHERE user_id = ?", (new_exp, now, user_id))
    conn.commit()
    conn.close()

    return (uid, name, linh_can, speed, realm_idx, new_exp, linh_thach, bonus_rate, now, last_explore), gained_exp

# ================= GIAO DIỆN TƯƠNG TÁC (BUTTONS) =================
class DaoDoView(discord.ui.View):
    def __init__(self, user_id, can_breakthrough):
        super().__init__(timeout=180)
        self.user_id = user_id
        self.btn_breakthrough.disabled = not can_breakthrough

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ Ngọc giản của đạo hữu khác, xin chớ tự ý chạm vào!", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="⚡ Xung Quan Độ Kiếp", style=discord.ButtonStyle.danger)
    async def btn_breakthrough(self, interaction: discord.Interaction, button: discord.ui.Button):
        player, _ = update_cultivation(self.user_id)
        uid, name, linh_can, speed, realm_idx, exp, linh_thach, bonus_rate, _, _ = player
        current_realm = REALMS[realm_idx]

        if exp < current_realm["max_exp"] or realm_idx >= len(REALMS) - 1:
            return await interaction.response.send_message("⚠️ Tu vi chưa đạt viên mãn hoặc đã đến đỉnh phong của thiên địa!", ephemeral=True)

        total_rate = min(1.0, current_realm["rate"] + bonus_rate)
        roll = random.random()

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()

        if roll <= total_rate:
            new_idx = realm_idx + 1
            new_exp = exp - current_realm["max_exp"]
            c.execute("UPDATE players SET realm_idx = ?, exp = ?, bonus_rate = 0.0 WHERE user_id = ?", (new_idx, new_exp, self.user_id))
            conn.commit()
            conn.close()

            next_r = REALMS[new_idx]
            embed = discord.Embed(
                title="🌩️ ĐỘ KIẾP THÀNH CÔNG - ĐẠO CƠ THĂNG HOA!",
                description=(
                    f"Chúc mừng đạo hữu **{name}** đã nghịch thiên cải mệnh, vượt qua lôi kiếp bước vào cảnh giới:\n"
                    f"## 💠 {next_r['name']} 💠\n"
                    f"❤️ Khí Huyết: `{next_r['hp']:,}` | 🗡️ Công Kích: `{next_r['atk']:,}` | 🛡️ Phòng Ngự: `{next_r['def']:,}`"
                ),
                color=discord.Color.from_rgb(241, 196, 15)
            )
        else:
            lost_exp = int(current_realm["max_exp"] * 0.25)
            new_exp = max(0, exp - lost_exp)
            c.execute("UPDATE players SET exp = ? WHERE user_id = ?", (new_exp, self.user_id))
            conn.commit()
            conn.close()

            embed = discord.Embed(
                title="🩸 XUNG QUAN THẤT BẠI - TẨU HỎA NHẬP MA!",
                description=(
                    f"Đạo hữu **{name}** {random.choice(FAIL_MESSAGES)}\n"
                    f"📉 Tổn thất tu vi: **-{lost_exp:,} Linh Khí**\n"
                    f"*Hãy sử dụng Đan Dược ngay trên bảng thông tin để gia tăng tỷ lệ độ kiếp lần sau!*"
                ),
                color=discord.Color.from_rgb(192, 57, 43)
            )

        await interaction.response.edit_message(embed=embed, view=None)

    @discord.ui.button(label="🗺️ Thám Hiểm Bí Cảnh", style=discord.ButtonStyle.primary)
    async def btn_explore(self, interaction: discord.Interaction, button: discord.ui.Button):
        player = get_player(self.user_id)
        now = int(time.time())
        cooldown = 300 # 5 phút (300 giây)
        
        if now - player[9] < cooldown:
            rem = cooldown - (now - player[9])
            return await interaction.response.send_message(
                f"⏳ Đạo hữu vừa rời khỏi bí cảnh, thần thức cần nghỉ ngơi thêm **{rem} giây** nữa!", 
                ephemeral=True
            )

        realm_mult = player[4] + 1
        events = [
            ("Đi sâu vào Vạn Yêu Sơn Mạch, chém giết Yêu Thú thu được yêu đan!", 120 * realm_mult, 40 * realm_mult),
            ("Phát hiện động phủ của bậc tiền bối tọa hóa, lĩnh ngộ được tàn quyển công pháp!", 250 * realm_mult, 20 * realm_mult),
            ("Hái được một cây Thiên Niên Linh Chi bên vách đá dựng đứng!", 180 * realm_mult, 60 * realm_mult),
            ("Chạm trán hung thú thượng cổ, phải đốt cháy tinh huyết để độn thổ thoát thân!", -80 * realm_mult, 0),
        ]
        desc, exp_gain, stone_gain = random.choice(events)

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("""UPDATE players 
                     SET exp = MAX(0, exp + ?), linh_thach = MAX(0, linh_thach + ?), last_explore = ? 
                     WHERE user_id = ?""", (exp_gain, stone_gain, now, self.user_id))
        conn.commit()
        conn.close()

        exp_txt = f"+{exp_gain:,}" if exp_gain >= 0 else f"{exp_gain:,}"
        await interaction.response.send_message(
            f"⛰️ **Lịch Luyện Bí Cảnh:** {desc}\n✨ Linh khí: **`{exp_txt}`** | 💎 Linh thạch: **`+{stone_gain:,}`**",
            ephemeral=True
        )

    @discord.ui.button(label="💊 Mua Phá Cảnh Đan (+15% Độ Kiếp - 200 Linh Thạch)", style=discord.ButtonStyle.success)
    async def btn_pill(self, interaction: discord.Interaction, button: discord.ui.Button):
        player = get_player(self.user_id)
        if player[6] < 200:
            return await interaction.response.send_message("❌ Túi trữ vật không đủ **200 Linh Thạch** để cầu mua đan dược!", ephemeral=True)
        if player[7] >= 0.45:
            return await interaction.response.send_message("⚠️ Đạo hữu đã uống tối đa đan dược cho cảnh giới này (Tối đa +45%)!", ephemeral=True)

        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("UPDATE players SET linh_thach = linh_thach - 200, bonus_rate = bonus_rate + 0.15 WHERE user_id = ?", (self.user_id,))
        conn.commit()
        conn.close()

        await interaction.response.send_message(
            "💊 Đạo hữu đã phục dụng **Phá Cảnh Đan**, dược lực hóa mở kinh mạch, tỷ lệ độ kiếp tăng thêm **+15%**!",
            ephemeral=True
        )

# ================= KHỞI TẠO BOT & SLASH COMMANDS =================
class TuTienBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        init_db()
        await self.tree.sync()
        print("⚡ Thiên Đạo đã vận hành, đồng bộ Slash Commands hoàn tất!")

bot = TuTienBot()

@bot.tree.command(name="nhapdao", description="Cảm ứng thiên địa, kiểm tra Linh Căn và bước vào con đường tu tiên")
async def nhapdao(interaction: discord.Interaction):
    if get_player(interaction.user.id):
        return await interaction.response.send_message("⚠️ Đạo hữu đã có tên trên Tiên Tịch! Hãy dùng `/thongtin` để xem trạng thái.", ephemeral=True)

    weights = [r["weight"] for r in SPIRIT_ROOTS]
    chosen_root = random.choices(SPIRIT_ROOTS, weights=weights, k=1)[0]
    now = int(time.time())

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO players VALUES (?, ?, ?, ?, 0, 0, 150, 0.0, ?, 0)",
              (interaction.user.id, interaction.user.display_name, chosen_root["name"], chosen_root["speed"], now))
    conn.commit()
    conn.close()

    embed = discord.Embed(
        title="⛩️ KHAI MỞ TIÊN DUYÊN - TRẮC NGHIỆM LINH CĂN",
        description=f"Đạo hữu **{interaction.user.display_name}** đặt tay lên Trắc Linh Bi, hào quang vạn trượng phóng thẳng lên trời!",
        color=discord.Color.from_rgb(46, 204, 113)
    )
    embed.add_field(name="🧬 Tư Chất Linh Căn", value=f"**{chosen_root['name']}**\n*{chosen_root['desc']}*", inline=False)
    embed.add_field(name="🌊 Tốc Độ Hấp Thụ", value=f"`{chosen_root['speed']}x` Linh khí", inline=True)
    embed.add_field(name="💎 Túi Trữ Vật", value="`150` Hạ Phẩm Linh Thạch", inline=True)
    embed.set_footer(text="Sử dụng lệnh /thongtin để bế quan tu luyện và độ kiếp.")

    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="thongtin", description="Xem Ngọc Giản Mệnh Cách, thu hoạch tu vi bế quan và đột phá")
async def thongtin(interaction: discord.Interaction):
    player, gained_exp = update_cultivation(interaction.user.id)
    if not player:
        return await interaction.response.send_message("❌ Đạo hữu vẫn là phàm nhân chưa nhập đạo! Hãy dùng `/nhapdao` trước.", ephemeral=True)

    uid, name, linh_can, speed, realm_idx, exp, linh_thach, bonus_rate, _, _ = player
    r = REALMS[realm_idx]
    can_break = (exp >= r["max_exp"]) and (realm_idx < len(REALMS) - 1)

    pct = min(1.0, exp / r["max_exp"])
    filled = int(pct * 12)
    bar = "🟦" * filled + "⬛" * (12 - filled)
    total_rate = min(100, int((r["rate"] + bonus_rate) * 100))

    embed = discord.Embed(
        title=f"📜 Ngọc Giản Mệnh Cách — {name}",
        description=f"> *🧘 Bế quan thổ nạp vừa qua thu được: **`+{gained_exp:,}`** Linh Khí*",
        color=discord.Color.from_rgb(52, 152, 219)
    )
    embed.set_thumbnail(url=interaction.user.display_avatar.url)
    embed.add_field(name="🏔️ Cảnh Giới", value=f"**{r['name']}**", inline=True)
    embed.add_field(name="🧬 Linh Căn", value=f"{linh_can} (`{speed}x`)", inline=True)
    embed.add_field(name="💎 Linh Thạch", value=f"`{linh_thach:,}` viên", inline=True)
    embed.add_field(
        name="⚔️ Thuộc Tính Bản Mệnh",
        value=f"❤️ Khí Huyết: `{r['hp']:,}`  |  🗡️ Công Kích: `{r['atk']:,}`  |  🛡️ Phòng Ngự: `{r['def']:,}`",
        inline=False
    )
    embed.add_field(
        name=f"✨ Tu Vi Linh Khí ({int(pct * 100)}%)",
        value=f"{bar} `{exp:,} / {r['max_exp']:,}`\n🎯 Xác suất Độ Kiếp thành công: **`{total_rate}%`** *(Đan dược hỗ trợ: +{int(bonus_rate*100)}%)*",
        inline=False
    )
    embed.set_footer(text="Thiên đạo vô thân, duy chỉ có kẻ kiên trì mới đắc được trường sinh.")

    await interaction.response.send_message(embed=embed, view=DaoDoView(uid, can_break))

@bot.tree.command(name="thienbang", description="Xem Bảng Xếp Hạng Thiên Bảng - Top 10 Cường Giả Tu Chân Giới")
async def thienbang(interaction: discord.Interaction):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT name, realm_idx, exp, linh_can FROM players ORDER BY realm_idx DESC, exp DESC LIMIT 10")
    rows = c.fetchall()
    conn.close()

    if not rows:
        return await interaction.response.send_message("📜 Thiên Bảng hiện tại vẫn còn trống!", ephemeral=True)

    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
    lines = []
    for idx, (name, realm_idx, exp, linh_can) in enumerate(rows):
        realm_name = REALMS[realm_idx]["name"]
        lines.append(
            f"{medals[idx]} **{name}** — `{realm_name}`\n"
            f"╰┈➤ Tu vi: `{exp:,}` Linh khí | *{linh_can}*"
        )

    embed = discord.Embed(
        title="🏆 THIÊN ĐẠO KIM BẢNG — TOP 10 CƯỜNG GIẢ 🏆",
        description="\n\n".join(lines),
        color=discord.Color.from_rgb(230, 126, 34)
    )
    embed.set_footer(text="Kim Bảng đề danh, uy chấn bát hoang!")
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="tythi", description="Luận kiếm tỷ thí cùng đạo hữu khác để tranh đoạt Linh Thạch")
@app_commands.describe(doi_thu="Chọn đạo hữu bạn muốn khiêu chiến")
async def tythi(interaction: discord.Interaction, doi_thu: discord.Member):
    if doi_thu.id == interaction.user.id or doi_thu.bot:
        return await interaction.response.send_message("❌ Không thể tự tỷ thí với bản thân hoặc Khôi Lỗi (Bot)!", ephemeral=True)

    p1, _ = update_cultivation(interaction.user.id)
    p2, _ = update_cultivation(doi_thu.id)

    if not p1:
        return await interaction.response.send_message("❌ Đạo hữu chưa nhập đạo (`/nhapdao`)!", ephemeral=True)
    if not p2:
        return await interaction.response.send_message(f"❌ **{doi_thu.display_name}** vẫn là phàm nhân chưa nhập đạo!", ephemeral=True)

    r1 = REALMS[p1[4]]
    r2 = REALMS[p2[4]]

    # Tính sức mạnh chiến đấu có pha chút biến số ngẫu nhiên (85% - 115%)
    power1 = (r1["hp"] + r1["atk"] * 5 + r1["def"] * 3) * random.uniform(0.85, 1.15)
    power2 = (r2["hp"] + r2["atk"] * 5 + r2["def"] * 3) * random.uniform(0.85, 1.15)

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    if power1 >= power2:
        winner, loser = p1, p2
        loot = min(loser[6], max(10, int(loser[6] * 0.1)))
        c.execute("UPDATE players SET linh_thach = linh_thach + ? WHERE user_id = ?", (loot, winner[0]))
        c.execute("UPDATE players SET linh_thach = MAX(0, linh_thach - ?) WHERE user_id = ?", (loot, loser[0]))
    else:
        winner, loser = p2, p1
        loot = min(loser[6], max(10, int(loser[6] * 0.1)))
        c.execute("UPDATE players SET linh_thach = linh_thach + ? WHERE user_id = ?", (loot, winner[0]))
        c.execute("UPDATE players SET linh_thach = MAX(0, linh_thach - ?) WHERE user_id = ?", (loot, loser[0]))

    conn.commit()
    conn.close()

    embed = discord.Embed(
        title="⚔️ LUẬN KIẾM ĐÀI — KẾT QUẢ TỶ THÍ ⚔️",
        description=(
            f"🗡️ **{p1[1]}** (`{r1['name']}`) giao đấu cùng 🛡️ **{p2[1]}** (`{r2['name']}`)!

"
            f"🔥 Sau hàng trăm hiệp đấu kiếm khí纵 hoành, **{winner[1]}** đã tung chiêu quyết định đánh bại **{loser[1]}**!
"
            f"💎 Chiến lợi phẩm thu được: **`{loot:,}` Linh Thạch**."
        ),
        color=discord.Color.from_rgb(155, 89, 182)
    )
    await interaction.response.send_message(embed=embed)

if __name__ == "__main__":
    TOKEN = os.getenv("DISCORD_TOKEN", "YOUR_BOT_TOKEN")
    bot.run(TOKEN)
