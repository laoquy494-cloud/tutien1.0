# ⛩️ Bot Discord Game Tu Tiên Truyền Thống (Python)

Bộ mã nguồn hoàn chỉnh cho Bot Discord Game Tu Tiên Cổ Phong sử dụng `discord.py` (Slash Commands + UI Buttons) và cơ sở dữ liệu `SQLite3` tích hợp sẵn.

## 📦 Cấu trúc thư mục
- `main.py`: Mã nguồn chính chứa toàn bộ hệ thống Cảnh giới, Linh căn, Độ kiếp, Bí cảnh, Thiên bảng và Tỷ thí.
- `requirements.txt`: Danh sách thư viện cần thiết.
- `README.md`: Hướng dẫn cài đặt và vận hành.

## 🚀 Hướng dẫn cài đặt và chạy Bot
1. **Cài đặt thư viện:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Cấu hình Token:**
   Mở file `main.py`, tìm dòng cuối cùng `TOKEN = os.getenv("DISCORD_TOKEN", "YOUR_BOT_TOKEN")` và thay `"YOUR_BOT_TOKEN"` bằng Token Bot của bạn (từ Discord Developer Portal).
3. **Khởi chạy Bot:**
   ```bash
   python main.py
   ```

## 🎮 Danh sách Lệnh (Slash Commands)
- `/nhapdao`: Trắc nghiệm Linh Căn (Ngụy, Chân, Dị, Thiên, Hỗn Độn Linh Căn) và khởi tạo nhân vật.
- `/thongtin`: Xem Ngọc Giản Mệnh Cách, tự động thu hoạch Linh Khí bế quan theo thời gian thực, kèm 3 nút tương tác:
  - **⚡ Xung Quan Độ Kiếp**: Đột phá lên cảnh giới mới.
  - **🗺️ Thám Hiểm Bí Cảnh**: Săn yêu thú, tìm cơ duyên (5 phút/lần).
  - **💊 Mua Phá Cảnh Đan**: Tiêu hao 200 Linh Thạch để cộng thêm 15% tỷ lệ Độ Kiếp thành công.
- `/thienbang`: Xem Top 10 Cường Giả trên Thiên Đạo Kim Bảng.
- `/tythi`: Khiêu chiến đạo hữu khác trong Server để luận kiếm và đoạt Linh Thạch.
